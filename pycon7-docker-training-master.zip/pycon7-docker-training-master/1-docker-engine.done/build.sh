sudo docker build -t pyconsette/ex1 .

sudo docker run -it --rm --name aiohttpdemo_pg postgres:latest

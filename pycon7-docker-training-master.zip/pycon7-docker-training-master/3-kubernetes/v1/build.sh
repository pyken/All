sudo docker build -t pyconsette/kitten:v1 .

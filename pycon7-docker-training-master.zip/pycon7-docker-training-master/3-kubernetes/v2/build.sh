sudo docker build -t pyconsette/kitten:v2 .
